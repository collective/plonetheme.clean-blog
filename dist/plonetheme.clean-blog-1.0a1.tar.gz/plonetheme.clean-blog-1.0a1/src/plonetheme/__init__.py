# -*- coding: utf-8 -*-
__import__('pkg_resources').declare_namespace(__name__)
